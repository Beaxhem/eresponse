from eresponse.resp import new_success_message, new_error_message
